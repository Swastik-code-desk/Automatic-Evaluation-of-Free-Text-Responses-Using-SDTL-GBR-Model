# 🌲 Automated Short Answer Scoring using Semantic Tree Logic & Machine Learning

[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Framework: Flask](https://img.shields.io/badge/Framework-Flask-black.svg)](https://flask.palletsprojects.com/)
[![ML: Scikit--Learn](https://img.shields.io/badge/ML-Scikit--Learn-orange.svg)](https://scikit-learn.org/)
[![Dataset: Kaggle](https://img.shields.io/badge/Dataset-Kaggle%20ASAP--SAS%20%26%20Mohler-blueviolet.svg)](https://www.kaggle.com/)

An end-to-end Machine Learning web application and research pipeline for **Automated Short Answer Scoring (ASAS)** using **Semantic Dependency Tree Logic Algorithms** and **Gradient Boosting Regression (SDTL-GBR)**.

The system evaluates student answer sheets against question papers and teacher answer keys, identifies **Missing vs. Present Keywords**, computes tree edit distances, and provides fair, monotonic grading with visual tree diagrams.

---

## 📑 Table of Contents
- [Key Features](#-key-features)
- [How the Semantic Tree Algorithm Works](#-how-the-semantic-tree-algorithm-works)
- [Datasets Included (Kaggle & Benchmarks)](#-datasets-included-kaggle--benchmarks)
- [Project Directory Structure](#-project-directory-structure)
- [Installation & Setup](#-installation--setup)
- [Model Training (PyCharm & Jupyter Lab)](#-model-training-pycharm--jupyter-lab)
- [Running the Web Dashboard](#-running-the-web-dashboard)
- [Research Paper Methodology](#-research-paper-methodology)
- [License & Citation](#-license--citation)

---

## 🌟 Key Features

1. **Semantic Dependency Tree Logic**:
   - Parses questions, answer keys, and student answers into syntactic-semantic trees (Root actions, Subject subtrees, Object subtrees, Modifiers, Negations).
   - Computes **Tree Edit Distance (TED)**, **Subtree Alignment**, and **Subject-Predicate-Object (SPO) Triples**.
2. **Strict Monotonic Keyword Scoring**:
   - **Irrelevancy Guarantee ($0.0$ Marks)**: If a student answer matches $0\%$ of the mandatory keywords, the system immediately flags it as irrelevant and awards $0.0$ marks.
   - **Full Marks Guarantee ($100\%$)**: If all keywords and semantic relationships are satisfied, full marks are awarded.
   - **Monotonicity**: More missing keywords *strictly* lowers the awarded marks ($Score \le C_{kw}$).
3. **Multi-Dataset Benchmarking (including Kaggle)**:
   - Pre-packaged with real benchmark samples from the **Mohler Short Answer Grading Dataset** (Kaggle/UNT) and **Hewlett Foundation ASAP-SAS** (Kaggle competition).
   - CLI and Jupyter loaders to train on any dataset with one command.
4. **Interactive Web Application**:
   - Built with Flask, vanilla JavaScript, and modern SVG canvas tree visualizer.
   - Live color-coded keyword tags (✅ Found in Green, ❌ Missing in Red), score progress bars, and teacher feedback.

---

## 🧠 How the Semantic Tree Algorithm Works

```mermaid
graph TD
    A[Question Paper & Reference Answer Key] --> B[Generate Reference Tree T_R]
    C[Student Marksheet / Answer Text] --> D[Generate Student Tree T_S]
    
    B --> E[Extract Predicates, SPO Triples, Depth Weights]
    D --> F[Extract Predicates, SPO Triples, Depth Weights]
    
    E & F --> G[Semantic Tree Logic Engine]
    
    G --> H1[Tree Edit Distance TED]
    G --> H2[Depth-Weighted Subtree Overlap]
    G --> H3[SPO Structural Alignment Match]
    G --> H4[Keyword Node Coverage C_kw]
    G --> H5[Negation Polarity Check]
    G --> H6[Length Ratio]
    
    H1 & H2 & H3 & H4 & H5 & H6 --> I[Feature Vector x]
    I --> J[Trained Gradient Boosting Regressor]
    J --> K[Predicted Mark & Grade]
    G --> L[Missing Keywords List & SVG Graph]
```

### Feature Definitions:
| Feature | Description | Range |
| :--- | :--- | :--- |
| **Tree Edit Distance (TED)** | Levenshtein-style tree operations (insertions, deletions, substitutions) to transform $T_S$ into $T_R$. | $0.0 - 1.0$ |
| **Subtree Overlap** | Jaccard overlap of concept sub-branches weighted inversely by depth $w(v)/(d(v)+1)$. | $0.0 - 1.0$ |
| **SPO Triples Match** | Verification of $\langle \text{Subject}, \text{Predicate}, \text{Object} \rangle$ relational triples. | $0.0 - 1.0$ |
| **Keyword Coverage ($C_{kw}$)** | Percentage of mandatory domain terms found in student tree. | $0.0 - 1.0$ |
| **Negation Penalty** | Penalty triggered if student introduces contradicting negation operators (*not, never, fails*). | $0.0 \text{ or } 1.0$ |

---

## 📊 Datasets Included (Kaggle & Benchmarks)

This repository includes benchmark short-answer grading datasets ready for training:

| Dataset | File Path | Description | Source |
| :--- | :--- | :--- | :--- |
| **Mohler Short Answer Dataset** | `data/mohler_short_answer_dataset.csv` | Computer Science Q&A (Data Structures, OOP, OS) scored by instructors on 0.0–5.0 scale. | [Mohler et al. / Kaggle](https://www.kaggle.com/datasets/saurabhshahane/short-answer-grading-dataset) |
| **Kaggle ASAP-SAS** | `data/asap_sas_sample.csv` | Real student assessment prize dataset on science prompts double-scored by teachers. | [Kaggle ASAP-SAS Competition](https://www.kaggle.com/c/asap-sas) |
| **Synthetic Multi-Subject** | `models/dataset.csv` | Balanced multi-subject dataset (Biology, Physics, Chemistry, CS) with strict monotonicity. | Built-in generator |

### Downloading the Full Scale Kaggle Datasets:
To download the complete multi-thousand sample competition corpus, run:
```bash
python data/download_kaggle_dataset.py
```
*(Requires Kaggle API credentials `kaggle.json`)*.

---

## 📁 Project Directory Structure

```
semantic_answer_evaluator/
├── data/
│   ├── dataset_loader.py              # Unified loader for all datasets
│   ├── download_kaggle_dataset.py     # Guide & script for full Kaggle downloads
│   ├── mohler_short_answer_dataset.csv# Mohler benchmark dataset (Kaggle/UNT)
│   └── asap_sas_sample.csv            # Kaggle ASAP-SAS dataset sample
├── models/
│   ├── dataset.csv                    # Training dataset cache
│   ├── semantic_tree_grader.joblib    # Trained Gradient Boosting Regressor
│   └── feature_scaler.joblib          # Standard feature scaler
├── nlp_engine/
│   ├── __init__.py
│   ├── semantic_tree.py               # Core Semantic Tree Logic & Graph Parser
│   ├── keyword_extractor.py           # Missing & Present Keyword Extraction
│   └── evaluator.py                   # Monotonic Evaluation Pipeline & Rules
├── static/
│   ├── css/
│   │   └── style.css                  # Modern glassmorphism dashboard UI
│   └── js/
│       ├── main.js                    # Web application frontend controller
│       └── tree_visualizer.js         # Interactive SVG Semantic Tree Visualizer
├── templates/
│   └── index.html                     # Responsive Flask dashboard
├── app.py                             # Flask web application server
├── train_model.py                     # CLI model training script
├── train_model.ipynb                  # Interactive Jupyter Lab training notebook
├── requirements.txt                   # Project dependencies
├── CITATION.cff                       # Research paper citation metadata
├── LICENSE                            # MIT License
└── README.md                          # Repository documentation
```

---

## 🚀 Installation & Setup

### 1. Clone or Download Repository
```bash
git clone https://github.com/your-username/semantic-answer-evaluator.git
cd semantic_answer_evaluator
```

### 2. Create Virtual Environment & Install Dependencies
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Install requirements
pip install -r requirements.txt
```

---

## 🎓 Model Training (PyCharm & Jupyter Lab)

### Option A: Command Line / PyCharm (`train_model.py`)
Train on the default dataset:
```bash
python train_model.py
```

Train on the **Mohler Kaggle Dataset**:
```bash
python train_model.py --dataset mohler
```

Train on the **Hewlett Foundation ASAP-SAS Kaggle Dataset**:
```bash
python train_model.py --dataset asap
```

### Option B: Jupyter Lab (`train_model.ipynb`)
Launch Jupyter Lab:
```bash
jupyter lab
```
Open `train_model.ipynb` to step through tree building, dataset comparisons, feature extraction, and scatter plot calibration.

---

## 🌐 Running the Web Dashboard

Start the local Flask server:
```bash
python app.py
```

Open your browser at:
👉 **`http://127.0.0.1:5000`**

### Using the Interface:
1. **Card 1**: Enter the question, reference answer key, maximum marks, and mandatory keywords.
2. **Card 2**: Paste or type the student's answer sheet response.
3. **Click "Evaluate Answer"**:
   - View assigned score, percentage, and letter grade.
   - Inspect ✅ **Found Keywords** (Green) vs ❌ **Missing Keywords** (Red).
   - Switch between **Reference Semantic Tree** and **Student Semantic Tree** in the interactive SVG viewer.
   - Inspect the numerical 4-feature vector (TED, Subtree Overlap, SPO Triples, Keyword Coverage).

---

## 📑 Research Paper Methodology

If describing this system in a research paper:

> **Algorithm**: *Semantic Dependency Tree Logic & Gradient Boosting Regressor (SDTL-GBR)*
>
> 1. **Representation**: Texts are parsed into rooted dependency trees $T = (V, E)$ with syntactic depth $d(v)$ and role weights $w(v)$.
> 2. **Structural Distance**: Tree Edit Distance $TED(T_R, T_S) = 1.0 - \frac{\text{Distance}(T_R, T_S)}{\max(|V_R|, |V_S|)}$.
> 3. **Semantic Overlap**: Depth-weighted subtree overlap $S_{overlap} = \frac{\sum_{v \in V_R \cap V_S} \frac{w(v)}{d(v)+1}}{\sum_{v \in V_R} \frac{w(v)}{d(v)+1}}$.
> 4. **Relation Match**: Triples alignment $SPO_{match} = \frac{|\text{Triples}(T_R) \cap \text{Triples}(T_S)|}{|\text{Triples}(T_R)|}$.
> 5. **Monotonic Scoring Constraint**:
>    $$\text{Final Marks} = \text{MaxMarks} \times \min\left(C_{kw}, \; C_{kw} \cdot \left[0.65 + 0.20 S_{overlap} + 0.15 SPO_{match}\right] \cdot \left[0.85 + 0.15 \hat{y}_{ML}\right]\right)$$

---

## 📜 License & Citation

This project is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

### Citation:
```bibtex
@software{semantic_answer_evaluator2026,
  author = {Student Researcher},
  title = {Semantic Dependency Tree Logic & Machine Learning for Automated Short Answer Scoring},
  year = {2026},
  url = {https://github.com/your-username/semantic-answer-evaluator}
}
```
