"""
Kaggle Dataset Downloader and Guide for Short Answer Scoring.

This script explains and assists with downloading full datasets directly from Kaggle:
1. Hewlett Foundation: Automated Student Assessment Prize - Short Answer Scoring (ASAP-SAS)
   Competition: https://www.kaggle.com/c/asap-sas
2. Mohler Short Answer Grading Dataset:
   Dataset: https://www.kaggle.com/datasets/saurabhshahane/short-answer-grading-dataset
"""

import os
import sys

def print_kaggle_instructions():
    print("=" * 70)
    print(" 📥 KAGGLE SHORT ANSWER SCORING DATASET INSTRUCTIONS")
    print("=" * 70)
    print("""
This project already comes bundled with preprocessed samples from:
1. Mohler Short Answer Grading Dataset (`data/mohler_short_answer_dataset.csv`)
2. Hewlett Foundation ASAP-SAS Dataset (`data/asap_sas_sample.csv`)
3. Synthetic Multi-Subject Dataset (`models/dataset.csv`)

To download the COMPLETE full-scale datasets (thousands of essays/short answers)
directly from Kaggle, follow these steps:

--- STEP 1: Install Kaggle CLI ---
Run in terminal:
    pip install kaggle

--- STEP 2: Configure Kaggle API Token ---
1. Log in to your Kaggle account (https://www.kaggle.com).
2. Go to: Settings -> API -> Click 'Create New Token'.
3. This downloads `kaggle.json`.
4. Place `kaggle.json` into:
   - Windows: C:\\Users\\<Your-Username>\\.kaggle\\kaggle.json
   - Linux/Mac: ~/.kaggle/kaggle.json

--- STEP 3: Download ASAP-SAS Competition Dataset ---
Run in terminal:
    kaggle competitions download -c asap-sas -p ./data/raw/

--- STEP 4: Download Mohler Dataset ---
Run in terminal:
    kaggle datasets download -d saurabhshahane/short-answer-grading-dataset -p ./data/raw/

Once downloaded, unzip the files into `./data/raw/` and use `data/dataset_loader.py`
to train models on the entire benchmark!
""")
    print("=" * 70)

if __name__ == "__main__":
    print_kaggle_instructions()
