import re
from typing import List, Dict, Any, Set
from .semantic_tree import SemanticTreeBuilder

class KeywordExtractor:
    """
    Extracts key concept terms and compares reference concepts against student semantic trees.
    Identifies Present Keywords vs Missing Keywords.
    """
    def __init__(self):
        self.builder = SemanticTreeBuilder()

    def extract_key_concepts(self, text: str, explicit_keywords: List[str] = None) -> List[str]:
        """
        Extracts key domain words and multi-word phrases from reference text.
        """
        concepts = set()

        if explicit_keywords:
            for kw in explicit_keywords:
                cleaned_kw = kw.strip().lower()
                if cleaned_kw:
                    concepts.add(cleaned_kw)

        # Auto-extract non-stopword nouns and domain verbs if no explicit keywords provided
        if not concepts:
            clean_text = re.sub(r'[^\w\s]', ' ', text)
            words = clean_text.split()
            for w in words:
                w_lower = w.lower()
                if len(w_lower) > 3 and w_lower not in self.builder.STOPWORDS and w_lower not in self.builder.NEGATIONS:
                    concepts.add(w_lower)

        return sorted(list(concepts))

    def evaluate_keywords(self, reference_text: str, student_text: str, explicit_keywords: List[str] = None) -> Dict[str, Any]:
        """
        Compares reference keywords against student text and semantic tree nodes.
        Returns present_keywords, missing_keywords, coverage_ratio, and irrelevancy flag.
        """
        required_concepts = self.extract_key_concepts(reference_text, explicit_keywords)

        if not required_concepts:
            return {
                "present_keywords": [],
                "missing_keywords": [],
                "keyword_coverage_ratio": 1.0,
                "total_required": 0,
                "is_completely_irrelevant": False
            }

        student_norm = student_text.lower()
        clean_stu_text = re.sub(r'[^\w\s]', ' ', student_text)
        stu_tokens = [self.builder._normalize_token(t) for t in clean_stu_text.split()]
        stu_token_set = set(stu_tokens)
        stu_raw_words = set(clean_stu_text.lower().split())

        present = []
        missing = []

        for concept in required_concepts:
            concept_lower = concept.lower().strip()
            norm_concept = self.builder._normalize_token(concept_lower)

            # 1. Exact phrase match or token match
            if concept_lower in student_norm or norm_concept in stu_token_set or concept_lower in stu_raw_words:
                present.append(concept)
                continue

            # 2. Multi-word phrase check (all tokens of keyphrase present)
            phrase_words = concept_lower.split()
            if len(phrase_words) > 1:
                all_match = True
                for pw in phrase_words:
                    pw_norm = self.builder._normalize_token(pw)
                    if pw not in stu_raw_words and pw_norm not in stu_token_set:
                        all_match = False
                        break
                if all_match:
                    present.append(concept)
                    continue

            # 3. Substring stem match for longer technical words (e.g. photo-synthesis)
            found_stem = False
            for tok in stu_token_set:
                if len(tok) >= 4 and len(norm_concept) >= 4:
                    if tok in norm_concept or norm_concept in tok:
                        found_stem = True
                        break

            if found_stem:
                present.append(concept)
            else:
                missing.append(concept)

        total_req = len(required_concepts)
        coverage_ratio = len(present) / total_req if total_req > 0 else 1.0
        is_completely_irrelevant = (len(present) == 0 and total_req > 0)

        return {
            "present_keywords": present,
            "missing_keywords": missing,
            "keyword_coverage_ratio": round(coverage_ratio, 4),
            "total_required": total_req,
            "is_completely_irrelevant": is_completely_irrelevant
        }
