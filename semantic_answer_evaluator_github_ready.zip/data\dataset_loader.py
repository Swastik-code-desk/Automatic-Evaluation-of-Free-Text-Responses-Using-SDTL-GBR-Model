"""
Dataset Loader for Semantic Answer Evaluator.
Supports:
1. Synthetic multi-subject benchmark ('default' or 'synthetic')
2. Mohler Short Answer Grading Dataset ('mohler')
3. Kaggle ASAP-SAS (Automated Student Assessment Prize) ('asap')
4. Custom user CSV files ('custom')
"""

import os
import pandas as pd
import numpy as np
from typing import Optional, List, Dict, Any

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(os.path.dirname(DATA_DIR), "models")

def load_dataset(dataset_type: str = "default", custom_path: Optional[str] = None) -> pd.DataFrame:
    """
    Loads and standardizes short-answer scoring datasets into standard columns:
    - question (str)
    - reference_answer (str)
    - keywords (str)
    - student_answer (str)
    - true_score (float, 0.0 to 1.0)
    """
    dataset_type = dataset_type.lower().strip()

    if custom_path and os.path.exists(custom_path):
        df = pd.read_csv(custom_path)
    elif dataset_type in ("mohler", "kaggle_mohler"):
        path = os.path.join(DATA_DIR, "mohler_short_answer_dataset.csv")
        df = pd.read_csv(path)
    elif dataset_type in ("asap", "asap_sas", "kaggle_asap"):
        path = os.path.join(DATA_DIR, "asap_sas_sample.csv")
        df = pd.read_csv(path)
    else:
        # Default synthetic multi-subject benchmark
        path = os.path.join(MODELS_DIR, "dataset.csv")
        if os.path.exists(path):
            df = pd.read_csv(path)
        else:
            from train_model import generate_sample_dataset
            df = generate_sample_dataset()

    # Standardize column names if needed
    column_mapping = {
        "essay_set": "question_id",
        "reference": "reference_answer",
        "model_answer": "reference_answer",
        "answer": "student_answer",
        "student_response": "student_answer",
        "score": "true_score",
        "normalized_score": "true_score"
    }
    df = df.rename(columns=column_mapping)

    # Normalize true_score to 0.0 - 1.0 if not already
    if "true_score" in df.columns:
        if df["true_score"].max() > 1.0:
            df["true_score"] = df["true_score"] / df["true_score"].max()
    elif "score_raw" in df.columns and "max_score" in df.columns:
        df["true_score"] = df["score_raw"] / df["max_score"]
    elif "score_raw" in df.columns:
        df["true_score"] = df["score_raw"] / df["score_raw"].max()

    # Ensure required columns are present
    required_cols = ["question", "reference_answer", "keywords", "student_answer", "true_score"]
    for col in required_cols:
        if col not in df.columns:
            if col == "keywords":
                # Auto-generate keywords placeholder from reference answer
                df["keywords"] = df["reference_answer"].apply(
                    lambda text: ", ".join([w.lower() for w in str(text).split() if len(w) > 4][:7])
                )
            else:
                raise ValueError(f"Dataset is missing required column: '{col}'")

    # Clean text values
    df["question"] = df["question"].astype(str)
    df["reference_answer"] = df["reference_answer"].astype(str)
    df["keywords"] = df["keywords"].astype(str)
    df["student_answer"] = df["student_answer"].astype(str)
    df["true_score"] = df["true_score"].astype(float).clip(0.0, 1.0)

    return df

def get_available_datasets() -> List[Dict[str, str]]:
    """Returns list of available short answer datasets."""
    return [
        {
            "id": "default",
            "name": "Synthetic Multi-Subject Benchmark",
            "description": "Balanced dataset covering Biology, Physics, Computer Science, and Chemistry.",
            "source": "Generated via train_model.py"
        },
        {
            "id": "mohler",
            "name": "Mohler Short Answer Grading Dataset (Kaggle/UNT)",
            "description": "Benchmark Computer Science Q&A dataset with instructor scores on Data Structures & OOP.",
            "source": "Mohler et al. (University of North Texas) / Kaggle short-answer-grading"
        },
        {
            "id": "asap",
            "name": "Hewlett Foundation ASAP-SAS (Kaggle Competition)",
            "description": "Real student assessment prize dataset on science prompts with double-scored answers.",
            "source": "Kaggle ASAP Short Answer Scoring (asap-sas)"
        }
    ]

if __name__ == "__main__":
    print("Available short answer scoring datasets:")
    for d in get_available_datasets():
        print(f" - [{d['id']}] {d['name']}: {d['description']}")
    df = load_dataset("mohler")
    print(f"\nLoaded Mohler dataset preview ({len(df)} rows):")
    print(df[["question", "student_answer", "true_score"]].head())
