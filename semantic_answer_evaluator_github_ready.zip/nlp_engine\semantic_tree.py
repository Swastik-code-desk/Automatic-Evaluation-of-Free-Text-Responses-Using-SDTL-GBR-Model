import re
import math
from typing import List, Dict, Any, Optional, Set, Tuple

class TreeNode:
    """
    Represents a node in a Semantic Dependency / Concept Tree.
    """
    def __init__(self, node_id: int, word: str, pos: str = "NOUN", role: str = "concept", depth: int = 0, weight: float = 1.0):
        self.node_id = node_id
        self.word = word.lower().strip()
        self.raw_word = word.strip()
        self.pos = pos.upper()  # VERB, NOUN, ADJ, NEG, ROOT, OBJ, SUBJ
        self.role = role        # root, nsubj, dobj, amod, neg, prep
        self.depth = depth
        self.weight = weight
        self.children: List['TreeNode'] = []
        self.parent: Optional['TreeNode'] = None

    def add_child(self, child_node: 'TreeNode'):
        child_node.parent = self
        child_node.depth = self.depth + 1
        self.children.append(child_node)

    def to_dict(self) -> Dict[str, Any]:
        """Convert tree to dictionary format for web JSON serialization."""
        return {
            "id": self.node_id,
            "word": self.raw_word,
            "pos": self.pos,
            "role": self.role,
            "depth": self.depth,
            "weight": self.weight,
            "children": [child.to_dict() for child in self.children]
        }


class SemanticTreeBuilder:
    """
    Builds a Semantic Dependency & Concept Tree from natural language answer text.
    Implements Syntactic & Role-based parsing logic.
    """
    STOPWORDS = {
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "in", "on", "at", "to", "for", "of", "with", "by", "from", "up", "about",
        "into", "over", "after", "this", "that", "these", "those", "it", "its"
    }

    NEGATIONS = {"not", "no", "never", "n't", "without", "lack", "fails", "cannot", "neither", "nor"}

    VERB_SUFFIXES = ("ing", "ed", "es", "ize", "ate", "ify")

    def __init__(self):
        pass

    def _normalize_token(self, token: str) -> str:
        """Basic stemmer/normalizer for matching concepts."""
        token = token.lower().strip()
        if len(token) > 4:
            if token.endswith("ing"):
                return token[:-3]
            if token.endswith("ed"):
                return token[:-2]
            if token.endswith("s") and not token.endswith("ss"):
                return token[:-1]
        return token

    def build_tree(self, text: str) -> TreeNode:
        """
        Parses text and constructs a hierarchical Semantic Tree.
        Root: Main Action / Process / Concept
        Branches: Subjects, Objects, Modifiers, Key Terms, Negations
        """
        clean_text = re.sub(r'[^\w\s\-\']', ' ', text)
        tokens = [t for t in clean_text.split() if t]

        if not tokens:
            return TreeNode(0, "EMPTY", pos="ROOT", role="root", depth=0)

        # Step 1: Identify root predicate / action or main topic
        root_token = "ROOT"
        root_pos = "ROOT"
        nodes_data = []

        # Simple POS tag heuristic
        for idx, tok in enumerate(tokens):
            tok_lower = tok.lower()
            norm = self._normalize_token(tok)

            if tok_lower in self.NEGATIONS:
                pos = "NEG"
                role = "negation"
                weight = 2.0
            elif tok_lower.endswith(self.VERB_SUFFIXES) or tok_lower in {"requires", "produces", "converts", "causes", "defines", "states", "forms"}:
                pos = "VERB"
                role = "predicate"
                weight = 1.5
            elif tok_lower not in self.STOPWORDS:
                pos = "NOUN"
                role = "concept"
                weight = 1.2
            else:
                pos = "FUNC"
                role = "modifier"
                weight = 0.5

            nodes_data.append({"id": idx + 1, "word": tok, "norm": norm, "pos": pos, "role": role, "weight": weight})

        # Find main verb / root concept
        root_idx = -1
        for i, nd in enumerate(nodes_data):
            if nd["pos"] == "VERB":
                root_idx = i
                break

        if root_idx == -1:
            # Fallback to first non-stopword noun
            for i, nd in enumerate(nodes_data):
                if nd["pos"] == "NOUN":
                    root_idx = i
                    break

        if root_idx == -1:
            root_idx = 0

        # Construct Root Node
        rdata = nodes_data[root_idx]
        root_node = TreeNode(rdata["id"], rdata["word"], pos=rdata["pos"], role="root", depth=0, weight=2.0)

        # Attach Left Subtree (Subjects & Negations before root)
        curr_parent = root_node
        subj_node = None
        for i in range(root_idx):
            nd = nodes_data[i]
            if nd["norm"] in self.STOPWORDS:
                continue
            child = TreeNode(nd["id"], nd["word"], pos=nd["pos"], role="subject" if nd["pos"] == "NOUN" else nd["role"], weight=nd["weight"])
            if nd["pos"] == "NEG":
                root_node.add_child(child)
            elif subj_node is None and nd["pos"] == "NOUN":
                subj_node = child
                root_node.add_child(child)
            elif subj_node is not None:
                subj_node.add_child(child)
            else:
                root_node.add_child(child)

        # Attach Right Subtree (Objects, Conditions, Modifiers after root)
        obj_node = None
        for i in range(root_idx + 1, len(nodes_data)):
            nd = nodes_data[i]
            if nd["norm"] in self.STOPWORDS:
                continue
            child = TreeNode(nd["id"], nd["word"], pos=nd["pos"], role="object" if nd["pos"] == "NOUN" else nd["role"], weight=nd["weight"])
            if obj_node is None and nd["pos"] == "NOUN":
                obj_node = child
                root_node.add_child(child)
            elif obj_node is not None:
                obj_node.add_child(child)
            else:
                root_node.add_child(child)

        return root_node


class SemanticTreeComparator:
    """
    Calculates tree logic matching algorithms between Reference Semantic Tree and Student Semantic Tree.
    """
    def __init__(self):
        self.builder = SemanticTreeBuilder()

    def _flatten_tree(self, root: TreeNode) -> List[TreeNode]:
        """Flattens tree nodes into a list via Depth-First Search."""
        nodes = []
        def dfs(node: TreeNode):
            nodes.append(node)
            for c in node.children:
                dfs(c)
        dfs(root)
        return nodes

    def _tree_edit_distance(self, tree1_nodes: List[TreeNode], tree2_nodes: List[TreeNode]) -> float:
        """
        Computes Tree Edit Distance (TED) ratio between reference and student semantic trees.
        Operations: Insertion (cost 1.0), Deletion (cost 1.0), Substitution (cost based on stem similarity).
        """
        n1 = len(tree1_nodes)
        n2 = len(tree2_nodes)

        if n1 == 0 and n2 == 0:
            return 1.0
        if n1 == 0 or n2 == 0:
            return 0.0

        # Matrix for Dynamic Programming (Levenshtein-style Tree Edit Distance approximation)
        dp = [[0.0] * (n2 + 1) for _ in range(n1 + 1)]

        for i in range(n1 + 1):
            dp[i][0] = i * 1.0
        for j in range(n2 + 1):
            dp[0][j] = j * 1.0

        for i in range(1, n1 + 1):
            node1 = tree1_nodes[i - 1]
            norm1 = self.builder._normalize_token(node1.word)
            for j in range(1, n2 + 1):
                node2 = tree2_nodes[j - 1]
                norm2 = self.builder._normalize_token(node2.word)

                if norm1 == norm2:
                    sub_cost = 0.0
                elif norm1 in norm2 or norm2 in norm1:
                    sub_cost = 0.3
                else:
                    sub_cost = 1.0

                dp[i][j] = min(
                    dp[i - 1][j] + 1.0,         # Deletion
                    dp[i][j - 1] + 1.0,         # Insertion
                    dp[i - 1][j - 1] + sub_cost # Substitution
                )

        max_len = max(n1, n2)
        dist = dp[n1][n2]
        similarity = max(0.0, 1.0 - (dist / max_len))
        return round(similarity, 4)

    def extract_spo_triples(self, root: TreeNode) -> List[Tuple[str, str, str]]:
        """Extracts Subject-Predicate-Object semantic triples from tree."""
        triples = []
        nodes = self._flatten_tree(root)

        root_word = root.word
        subjs = [n.word for n in nodes if n.role in {"subject", "nsubj"}]
        objs = [n.word for n in nodes if n.role in {"object", "dobj", "concept"}]

        if not subjs:
            subjs = ["subject"]
        if not objs:
            objs = ["object"]

        for s in subjs[:2]:
            for o in objs[:2]:
                if s != o:
                    triples.append((s, root_word, o))
        return triples

    def check_negation_polarity(self, root: TreeNode) -> bool:
        """Returns True if tree contains explicit negation modifying key concepts."""
        nodes = self._flatten_tree(root)
        for n in nodes:
            if n.pos == "NEG" or n.word in self.builder.NEGATIONS:
                return True
        return False

    def compute_similarity(self, ref_tree: TreeNode, student_tree: TreeNode) -> Dict[str, float]:
        """
        Executes full Semantic Tree Logic Comparison:
        - Tree Edit Distance Score
        - Depth-Weighted Subtree Overlap Score
        - Subject-Predicate-Object (SPO) Structural Alignment Score
        - Negation Penalty Flag
        """
        ref_nodes = self._flatten_tree(ref_tree)
        stu_nodes = self._flatten_tree(student_tree)

        # 1. Tree Edit Distance
        ted_score = self._tree_edit_distance(ref_nodes, stu_nodes)

        # 2. Depth-Weighted Subtree Overlap
        ref_stems = {self.builder._normalize_token(n.word): n.weight / (n.depth + 1) for n in ref_nodes if n.word not in self.builder.STOPWORDS}
        stu_stems = {self.builder._normalize_token(n.word) for n in stu_nodes if n.word not in self.builder.STOPWORDS}

        if not ref_stems:
            subtree_score = 1.0
        else:
            total_ref_weight = sum(ref_stems.values())
            matched_weight = sum(weight for stem, weight in ref_stems.items() if stem in stu_stems)
            subtree_score = matched_weight / max(total_ref_weight, 1e-5)

        # 3. SPO Triple Alignment
        ref_triples = self.extract_spo_triples(ref_tree)
        stu_triples = self.extract_spo_triples(student_tree)

        if not ref_triples:
            spo_score = 1.0
        else:
            matched_spo = 0
            for r_s, r_p, r_o in ref_triples:
                norm_p = self.builder._normalize_token(r_p)
                for s_s, s_p, s_o in stu_triples:
                    if norm_p == self.builder._normalize_token(s_p):
                        matched_spo += 1
                        break
            spo_score = matched_spo / len(ref_triples)

        # 4. Negation Penalty Check
        ref_neg = self.check_negation_polarity(ref_tree)
        stu_neg = self.check_negation_polarity(student_tree)

        # If student introduced an unexpected negation, apply penalty flag
        negation_penalty = 1.0 if (stu_neg and not ref_neg) else 0.0

        return {
            "tree_edit_distance_score": round(ted_score, 4),
            "subtree_overlap_score": round(min(1.0, subtree_score), 4),
            "spo_alignment_score": round(spo_score, 4),
            "negation_penalty": negation_penalty
        }
