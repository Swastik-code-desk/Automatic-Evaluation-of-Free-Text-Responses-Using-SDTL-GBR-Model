let currentEvaluationData = null;
let currentSampleData = [];
let treeVisualizer = null;
let activeTab = 'ref';

document.addEventListener('DOMContentLoaded', () => {
    treeVisualizer = new TreeVisualizer('tree-svg');

    fetchSamples();
    setupEventListeners();
});

function setupEventListeners() {
    // Evaluate Button
    document.getElementById('btn-evaluate').addEventListener('click', runEvaluation);

    // Retrain Model Button
    document.getElementById('btn-retrain').addEventListener('click', triggerRetrain);

    // Tree Tabs
    document.querySelectorAll('.tree-tab').forEach(tab => {
        tab.addEventListener('click', (e) => {
            document.querySelectorAll('.tree-tab').forEach(t => t.classList.remove('active'));
            e.target.classList.add('active');
            activeTab = e.target.dataset.tab;
            renderActiveTree();
        });
    });
}

async function fetchSamples() {
    try {
        const res = await fetch('/api/samples');
        const data = await res.json();
        if (data.status === 'success') {
            currentSampleData = data.samples;
            renderPresets();
        }
    } catch (err) {
        console.error('Error loading samples:', err);
    }
}

function renderPresets() {
    const container = document.getElementById('presets-container');
    container.innerHTML = '';

    currentSampleData.forEach((sample, idx) => {
        const btn = document.createElement('button');
        btn.className = `preset-btn ${idx === 0 ? 'active' : ''}`;
        btn.innerText = `${sample.subject}: ${sample.question.substring(0, 22)}...`;
        btn.onclick = () => selectSample(sample, btn);
        container.appendChild(btn);
    });
}

function selectSample(sample, btnElement) {
    document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
    if (btnElement) btnElement.classList.add('active');

    document.getElementById('question-text').value = sample.question;
    document.getElementById('reference-answer').value = sample.reference_answer;
    document.getElementById('max-marks').value = sample.max_marks;
    document.getElementById('key-concepts').value = sample.keywords.join(', ');

    // Default to excellent answer
    document.getElementById('student-answer').value = sample.sample_student_answers.excellent;
}

function loadSampleAnswer(quality) {
    const qText = document.getElementById('question-text').value;
    const found = currentSampleData.find(s => s.question.includes(qText.substring(0, 15)));

    if (found && found.sample_student_answers[quality]) {
        document.getElementById('student-answer').value = found.sample_student_answers[quality];
    } else {
        if (quality === 'excellent') {
            document.getElementById('student-answer').value = document.getElementById('reference-answer').value;
        } else if (quality === 'average') {
            document.getElementById('student-answer').value = "It uses sunlight and water to produce food.";
        } else {
            document.getElementById('student-answer').value = "Does not use sunlight or oxygen.";
        }
    }
}

async function runEvaluation() {
    const question = document.getElementById('question-text').value.trim();
    const referenceAnswer = document.getElementById('reference-answer').value.trim();
    const studentAnswer = document.getElementById('student-answer').value.trim();
    const maxMarks = parseFloat(document.getElementById('max-marks').value) || 10;
    const keywords = document.getElementById('key-concepts').value.trim();

    if (!referenceAnswer) {
        alert("Please enter a reference answer.");
        return;
    }

    const badge = document.getElementById('eval-status-badge');
    badge.innerText = "Processing Trees...";
    badge.className = "badge badge-active";

    try {
        const response = await fetch('/api/evaluate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                question: question,
                reference_answer: referenceAnswer,
                student_answer: studentAnswer,
                max_marks: maxMarks,
                keywords: keywords
            })
        });

        const data = await response.json();

        if (data.status === 'success') {
            currentEvaluationData = data.result;
            displayResults(data.result);
            badge.innerText = "Evaluation Complete";
            badge.className = "badge badge-idle";
        } else {
            alert("Evaluation Error: " + data.message);
            badge.innerText = "Error";
        }
    } catch (err) {
        console.error("API error:", err);
        alert("Server error connecting to evaluation pipeline.");
        badge.innerText = "Connection Error";
    }
}

function displayResults(res) {
    // Obtained Marks & Percentage
    document.getElementById('val-obtained-marks').innerText = res.obtained_marks;
    document.getElementById('val-max-marks').innerText = `/ ${res.max_marks}`;
    document.getElementById('val-percentage').innerText = `${res.percentage}%`;

    const progressBar = document.getElementById('score-progress-bar');
    progressBar.style.width = `${Math.max(5, res.percentage)}%`;

    // Grade Pill
    const gradePill = document.getElementById('val-grade-pill');
    gradePill.innerText = res.grade;

    if (res.percentage >= 80) gradePill.style.color = '#10b981';
    else if (res.percentage >= 60) gradePill.style.color = '#3b82f6';
    else if (res.percentage >= 50) gradePill.style.color = '#f59e0b';
    else gradePill.style.color = '#ef4444';

    // Keywords Lists
    const presentContainer = document.getElementById('present-keywords-list');
    presentContainer.innerHTML = '';
    if (res.present_keywords && res.present_keywords.length > 0) {
        res.present_keywords.forEach(kw => {
            presentContainer.innerHTML += `<span class="kw-badge kw-badge-green">✓ ${kw}</span>`;
        });
    } else {
        presentContainer.innerHTML = '<span class="placeholder-text">No matching keywords found</span>';
    }

    const missingContainer = document.getElementById('missing-keywords-list');
    missingContainer.innerHTML = '';
    if (res.missing_keywords && res.missing_keywords.length > 0) {
        res.missing_keywords.forEach(kw => {
            missingContainer.innerHTML += `<span class="kw-badge kw-badge-red">✗ ${kw}</span>`;
        });
    } else {
        missingContainer.innerHTML = '<span class="placeholder-text">All key concepts present!</span>';
    }

    // Features
    document.getElementById('feat-ted').innerText = res.features.tree_edit_distance_score;
    document.getElementById('feat-subtree').innerText = res.features.subtree_overlap_score;
    document.getElementById('feat-spo').innerText = res.features.spo_alignment_score;
    document.getElementById('feat-kw').innerText = res.features.keyword_coverage_ratio;

    // Feedback
    const fbList = document.getElementById('feedback-list');
    fbList.innerHTML = '';
    res.feedback.forEach(item => {
        fbList.innerHTML += `<li>${item}</li>`;
    });

    // Render Active Semantic Tree
    renderActiveTree();
}

function renderActiveTree() {
    if (!currentEvaluationData || !treeVisualizer) return;

    if (activeTab === 'ref') {
        treeVisualizer.renderTree(currentEvaluationData.reference_tree);
    } else {
        treeVisualizer.renderTree(currentEvaluationData.student_tree);
    }
}

async function triggerRetrain() {
    const btn = document.getElementById('btn-retrain');
    btn.innerText = "Training Model...";
    btn.disabled = true;

    try {
        const res = await fetch('/api/train', { method: 'POST' });
        const data = await res.json();
        alert(data.message);
    } catch (e) {
        alert("Training Error: " + e.message);
    } finally {
        btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg> Train ML Model`;
        btn.disabled = false;
    }
}
