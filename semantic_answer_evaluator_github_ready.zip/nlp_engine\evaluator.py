import os
import joblib
import numpy as np
from typing import Dict, Any, List, Optional
from .semantic_tree import SemanticTreeBuilder, SemanticTreeComparator
from .keyword_extractor import KeywordExtractor

class AnswerEvaluator:
    """
    Main Evaluation Pipeline combining Semantic Tree Logic, Keyword Extraction,
    and Machine Learning model inference with strict MONOTONIC marking rules.
    """
    def __init__(self, model_dir: str = None):
        self.tree_builder = SemanticTreeBuilder()
        self.comparator = SemanticTreeComparator()
        self.keyword_extractor = KeywordExtractor()

        if model_dir is None:
            model_dir = os.path.join(os.path.dirname(__file__), "..", "models")

        self.model_path = os.path.join(model_dir, "semantic_tree_grader.joblib")
        self.scaler_path = os.path.join(model_dir, "feature_scaler.joblib")

        self.model = None
        self.scaler = None
        self._load_model()

    def _load_model(self):
        """Loads trained ML model and scaler if available."""
        try:
            if os.path.exists(self.model_path) and os.path.exists(self.scaler_path):
                self.model = joblib.load(self.model_path)
                self.scaler = joblib.load(self.scaler_path)
                print(f"[AnswerEvaluator] Loaded trained ML model from {self.model_path}")
            else:
                print(f"[AnswerEvaluator] Trained model not found at {self.model_path}. Using Semantic Tree heuristic fallback.")
        except Exception as e:
            print(f"[AnswerEvaluator] Error loading ML model: {e}. Fallback to rule-based logic.")
            self.model = None
            self.scaler = None

    def extract_features(self, reference_answer: str, student_answer: str, key_concepts: List[str] = None) -> Dict[str, Any]:
        """
        Extracts 6 core Semantic Tree and NLP features from Reference and Student answers.
        """
        ref_tree = self.tree_builder.build_tree(reference_answer)
        stu_tree = self.tree_builder.build_tree(student_answer)

        # 1. Semantic Tree Comparison Metrics
        tree_metrics = self.comparator.compute_similarity(ref_tree, stu_tree)

        # 2. Keyword & Concept Coverage
        kw_metrics = self.keyword_extractor.evaluate_keywords(reference_answer, student_answer, key_concepts)

        # 3. Text Length Ratio
        ref_len = max(len(reference_answer.split()), 1)
        stu_len = len(student_answer.split())
        length_ratio = min(1.5, stu_len / ref_len)

        return {
            "tree_edit_distance_score": tree_metrics["tree_edit_distance_score"],
            "subtree_overlap_score": tree_metrics["subtree_overlap_score"],
            "spo_alignment_score": tree_metrics["spo_alignment_score"],
            "keyword_coverage_ratio": kw_metrics["keyword_coverage_ratio"],
            "negation_penalty": tree_metrics["negation_penalty"],
            "length_ratio": round(length_ratio, 4),
            "ref_tree": ref_tree,
            "stu_tree": stu_tree,
            "kw_metrics": kw_metrics
        }

    def _assign_grade(self, percentage: float) -> str:
        """Assigns letter grade based on percentage score."""
        if percentage >= 90: return "A+"
        if percentage >= 80: return "A"
        if percentage >= 70: return "B"
        if percentage >= 60: return "C"
        if percentage >= 50: return "D"
        return "F"

    def evaluate_answer(self, question: str, reference_answer: str, student_answer: str, max_marks: float = 10.0, key_concepts: List[str] = None) -> Dict[str, Any]:
        """
        Evaluates student answer sheet entry against question paper reference answer.
        Enforces strict MONOTONIC DOMAIN RULES:
        - More missing keywords strictly decreases the marks (Monotonicity Guarantee).
        - 0 keywords matched = 0 marks (Irrelevant).
        - 100% keywords matched + valid semantic tree = Full marks.
        - Upper bound score capped strictly by keyword coverage ratio (Score <= C_kw).
        """
        ref_tree_dict = self.tree_builder.build_tree(reference_answer).to_dict()

        if not student_answer.strip():
            return {
                "obtained_marks": 0.0,
                "max_marks": max_marks,
                "percentage": 0.0,
                "grade": "F",
                "features": {
                    "tree_edit_distance_score": 0.0,
                    "subtree_overlap_score": 0.0,
                    "spo_alignment_score": 0.0,
                    "keyword_coverage_ratio": 0.0,
                    "negation_penalty": 0.0,
                    "length_ratio": 0.0
                },
                "present_keywords": [],
                "missing_keywords": key_concepts or [],
                "feedback": ["Student answer sheet is empty. Awarded 0 marks."],
                "reference_tree": ref_tree_dict,
                "student_tree": self.tree_builder.build_tree("Empty").to_dict()
            }

        features = self.extract_features(reference_answer, student_answer, key_concepts)
        kw_data = features["kw_metrics"]
        kw_coverage = features["keyword_coverage_ratio"]
        neg_penalty = features["negation_penalty"]
        ted_score = features["tree_edit_distance_score"]
        subtree_score = features["subtree_overlap_score"]
        spo_score = features["spo_alignment_score"]

        present_kw = kw_data["present_keywords"]
        missing_kw = kw_data["missing_keywords"]
        total_req_kw = kw_data["total_required"]

        # =========================================================================
        # RULE 1: Zero Keywords Match -> ZERO MARKS (Irrelevancy)
        # =========================================================================
        if kw_coverage == 0.0 or kw_data.get("is_completely_irrelevant", False):
            return {
                "obtained_marks": 0.0,
                "max_marks": max_marks,
                "percentage": 0.0,
                "grade": "F",
                "features": {
                    "tree_edit_distance_score": ted_score,
                    "subtree_overlap_score": subtree_score,
                    "spo_alignment_score": spo_score,
                    "keyword_coverage_ratio": 0.0,
                    "negation_penalty": neg_penalty,
                    "length_ratio": features["length_ratio"]
                },
                "present_keywords": [],
                "missing_keywords": missing_kw,
                "feedback": [
                    "❌ Answer is completely irrelevant to the question.",
                    "Zero mandatory keywords matched.",
                    "Awarded 0.0 marks for irrelevancy."
                ],
                "reference_tree": ref_tree_dict,
                "student_tree": features["stu_tree"].to_dict()
            }

        # =========================================================================
        # RULE 2: Perfect Match (100% Keywords + No Negation) -> FULL MARKS
        # =========================================================================
        if kw_coverage == 1.0 and neg_penalty == 0.0 and (ted_score >= 0.70 or subtree_score >= 0.65):
            return {
                "obtained_marks": max_marks,
                "max_marks": max_marks,
                "percentage": 100.0,
                "grade": "A+",
                "features": {
                    "tree_edit_distance_score": ted_score,
                    "subtree_overlap_score": subtree_score,
                    "spo_alignment_score": spo_score,
                    "keyword_coverage_ratio": 1.0,
                    "negation_penalty": 0.0,
                    "length_ratio": features["length_ratio"]
                },
                "present_keywords": present_kw,
                "missing_keywords": [],
                "feedback": [
                    "🌟 Perfect response! Captures all required keywords and semantic concepts accurately.",
                    "Awarded full marks."
                ],
                "reference_tree": ref_tree_dict,
                "student_tree": features["stu_tree"].to_dict()
            }

        # =========================================================================
        # RULE 3: Strictly Monotonic Proportional Scoring
        # =========================================================================
        # Predict using ML Model if available
        X_vec = np.array([[
            ted_score,
            subtree_score,
            spo_score,
            kw_coverage,
            neg_penalty,
            features["length_ratio"]
        ]])

        if self.model and self.scaler:
            X_scaled = self.scaler.transform(X_vec)
            ml_pred = float(self.model.predict(X_scaled)[0])
        else:
            ml_pred = 0.5 * kw_coverage + 0.3 * subtree_score + 0.2 * ted_score

        # MONOTONIC FORMULA: Score is strictly bounded by keyword_coverage_ratio
        # Multiplicative factor ensures more missing keywords ALWAYS lowers the score!
        tree_factor = 0.65 + 0.20 * subtree_score + 0.15 * spo_score
        calibrated_score = kw_coverage * tree_factor * (0.85 + 0.15 * min(1.0, ml_pred))

        # Negation Penalty Deduction
        if neg_penalty > 0:
            calibrated_score *= 0.10  # 90% deduction for contradicting negation

        # Hard Ceiling: Score ratio CANNOT exceed kw_coverage (Prevents fluff answers from getting extra marks)
        final_ratio = max(0.0, min(kw_coverage, calibrated_score))

        obtained_marks = round(final_ratio * max_marks, 2)
        percentage = round(final_ratio * 100, 2)
        grade = self._assign_grade(percentage)

        feedback = []
        if percentage >= 90:
            feedback.append("Excellent answer! Captures core concepts and semantic structure accurately.")
        elif percentage >= 75:
            feedback.append("Good response. Demonstrates strong understanding with minor missing details.")
        elif percentage >= 50:
            feedback.append("Average response. Covers partial keywords but missing essential concepts.")
        else:
            feedback.append("Needs improvement. Answer misses critical required keywords and semantic concepts.")

        if missing_kw:
            feedback.append(f"Missing Keywords ({len(missing_kw)}/{total_req_kw}): {', '.join(missing_kw)}")

        if neg_penalty > 0:
            feedback.append("⚠️ Warning: Answer contains a negation that contradicts the reference answer meaning.")

        return {
            "obtained_marks": obtained_marks,
            "max_marks": max_marks,
            "percentage": percentage,
            "grade": grade,
            "features": {
                "tree_edit_distance_score": ted_score,
                "subtree_overlap_score": subtree_score,
                "spo_alignment_score": spo_score,
                "keyword_coverage_ratio": kw_coverage,
                "negation_penalty": neg_penalty,
                "length_ratio": features["length_ratio"]
            },
            "present_keywords": present_kw,
            "missing_keywords": missing_kw,
            "feedback": feedback,
            "reference_tree": ref_tree_dict,
            "student_tree": features["stu_tree"].to_dict()
        }
