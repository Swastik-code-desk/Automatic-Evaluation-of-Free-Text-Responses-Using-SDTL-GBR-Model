/**
 * Interactive SVG Visualizer for Semantic Dependency Trees.
 */
class TreeVisualizer {
    constructor(svgElementId) {
        this.svg = document.getElementById(svgElementId);
    }

    renderTree(treeData) {
        if (!this.svg || !treeData) return;

        // Clear existing SVG children
        this.svg.innerHTML = '';

        const width = this.svg.clientWidth || 580;
        const height = this.svg.clientHeight || 260;

        // Calculate positions recursively
        const nodes = [];
        const links = [];

        let currentId = 0;

        function traverse(node, depth, xStart, xEnd) {
            const x = (xStart + xEnd) / 2;
            const y = 45 + depth * 65;

            const nodeObj = {
                id: currentId++,
                word: node.word || 'node',
                pos: node.pos || 'CONCEPT',
                role: node.role || 'concept',
                x: x,
                y: y
            };

            nodes.push(nodeObj);

            if (node.children && node.children.length > 0) {
                const childWidth = (xEnd - xStart) / node.children.length;
                node.children.forEach((child, index) => {
                    const cXStart = xStart + index * childWidth;
                    const cXEnd = cXStart + childWidth;
                    const childObj = traverse(child, depth + 1, cXStart, cXEnd);
                    links.push({ source: nodeObj, target: childObj });
                });
            }

            return nodeObj;
        }

        traverse(treeData, 0, 20, width - 20);

        // Render Links (Curves)
        links.forEach(link => {
            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const d = `M ${link.source.x} ${link.source.y} C ${link.source.x} ${(link.source.y + link.target.y) / 2}, ${link.target.x} ${(link.source.y + link.target.y) / 2}, ${link.target.x} ${link.target.y}`;
            path.setAttribute('d', d);
            path.setAttribute('stroke', '#334155');
            path.setAttribute('stroke-width', '2');
            path.setAttribute('fill', 'none');
            this.svg.appendChild(path);
        });

        // Render Nodes
        nodes.forEach(n => {
            const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
            g.setAttribute('transform', `translate(${n.x}, ${n.y})`);

            // Node Circle
            const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            circle.setAttribute('r', '18');

            let fill = '#1e293b';
            let stroke = '#3b82f6';

            if (n.role === 'root' || n.pos === 'ROOT') {
                fill = '#1d4ed8'; stroke = '#60a5fa';
            } else if (n.pos === 'NEG' || n.role === 'negation') {
                fill = '#991b1b'; stroke = '#f87171';
            } else if (n.role === 'subject' || n.role === 'nsubj') {
                fill = '#065f46'; stroke = '#34d399';
            } else if (n.role === 'object' || n.role === 'dobj') {
                fill = '#92400e'; stroke = '#fbbf24';
            }

            circle.setAttribute('fill', fill);
            circle.setAttribute('stroke', stroke);
            circle.setAttribute('stroke-width', '2');

            // Word Label
            const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            text.textContent = n.word;
            text.setAttribute('text-anchor', 'middle');
            text.setAttribute('dy', '4');
            text.setAttribute('fill', '#f8fafc');
            text.setAttribute('font-size', '11px');
            text.setAttribute('font-weight', '700');

            // Role Badge Below
            const subtext = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            subtext.textContent = n.role.toUpperCase();
            subtext.setAttribute('text-anchor', 'middle');
            subtext.setAttribute('dy', '30');
            subtext.setAttribute('fill', '#94a3b8');
            subtext.setAttribute('font-size', '9px');
            subtext.setAttribute('font-weight', '600');

            g.appendChild(circle);
            g.appendChild(text);
            g.appendChild(subtext);

            this.svg.appendChild(g);
        });
    }
}
