import os
import json
from flask import Flask, render_template, request, jsonify
from nlp_engine.evaluator import AnswerEvaluator

app = Flask(__name__)

# Initialize Evaluator Pipeline
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, "models")
evaluator = AnswerEvaluator(model_dir=MODELS_DIR)

# Sample Preset Questions for Easy Testing
SAMPLE_QUESTIONS = [
    {
        "id": "q1",
        "subject": "Biology",
        "question": "What is photosynthesis and why is it important for living organisms?",
        "reference_answer": "Photosynthesis is the chemical process by which green plants convert light energy from sunlight, water, and carbon dioxide into chemical energy stored in glucose while releasing oxygen into the atmosphere.",
        "max_marks": 10,
        "keywords": ["photosynthesis", "sunlight", "carbon dioxide", "water", "glucose", "oxygen", "plants"],
        "sample_student_answers": {
            "excellent": "Photosynthesis is the biological process where green plants utilize sunlight, carbon dioxide, and water to synthesize glucose for energy and release oxygen gas.",
            "average": "Plants take in sunlight and water to produce food and oxygen.",
            "poor": "The French Revolution began in 1789 due to social inequality in France."
        }
    },
    {
        "id": "q2",
        "subject": "Physics",
        "question": "State and explain Newton's Second Law of Motion.",
        "reference_answer": "Newton's Second Law of Motion states that the acceleration of an object is directly proportional to the net applied force and inversely proportional to its mass, represented mathematically as Force equals mass times acceleration (F = m * a).",
        "max_marks": 10,
        "keywords": ["acceleration", "force", "mass", "proportional", "inversely", "formula"],
        "sample_student_answers": {
            "excellent": "Newton's second law states that force equals mass multiplied by acceleration, F = ma.",
            "average": "Force depends on mass and how fast an object accelerates.",
            "poor": "Database normalization is used to organize relational database tables."
        }
    },
    {
        "id": "q3",
        "subject": "Computer Science",
        "question": "Explain process deadlock in operating systems and its necessary conditions.",
        "reference_answer": "A deadlock in operating systems occurs when two or more executing processes are unable to proceed because each is waiting for a resource held by another process in a circular wait condition.",
        "max_marks": 10,
        "keywords": ["deadlock", "process", "blocked", "resource", "waiting", "circular"],
        "sample_student_answers": {
            "excellent": "Deadlock is a state where processes are permanently blocked while waiting for resources held by each other in a circular dependency.",
            "average": "Deadlock happens when processes freeze waiting for system resources.",
            "poor": "Cooking pasta requires boiling water and adding salt to taste."
        }
    }
]

@app.route('/')
def index():
    """Render main application dashboard."""
    return render_template('index.html')

@app.route('/api/samples', methods=['GET'])
def get_samples():
    """Return pre-loaded Q&A samples."""
    return jsonify({"status": "success", "samples": SAMPLE_QUESTIONS})

@app.route('/api/evaluate', methods=['POST'])
def evaluate():
    """API Endpoint to evaluate student answer sheet against question paper."""
    try:
        data = request.json or {}

        question = data.get("question", "")
        reference_answer = data.get("reference_answer", "")
        student_answer = data.get("student_answer", "")
        max_marks = float(data.get("max_marks", 10.0))

        raw_keywords = data.get("keywords", "")
        if isinstance(raw_keywords, str):
            key_concepts = [k.strip() for k in raw_keywords.split(",") if k.strip()]
        elif isinstance(raw_keywords, list):
            key_concepts = [str(k).strip() for k in raw_keywords if str(k).strip()]
        else:
            key_concepts = []

        if not reference_answer.strip():
            return jsonify({"status": "error", "message": "Reference answer cannot be empty."}), 400

        result = evaluator.evaluate_answer(
            question=question,
            reference_answer=reference_answer,
            student_answer=student_answer,
            max_marks=max_marks,
            key_concepts=key_concepts
        )

        return jsonify({"status": "success", "result": result})

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/train', methods=['POST'])
def retrain():
    """API Endpoint to trigger model retraining."""
    try:
        from train_model import main as train_main
        train_main()
        evaluator._load_model()
        return jsonify({"status": "success", "message": "ML Model retrained and updated successfully with strict rules!"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    print("=" * 60)
    print(" 🚀 STARTING SEMANTIC TREE ANSWER EVALUATOR WEB APP")
    print(" 🌐 Server running at: http://127.0.0.1:5000")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5000, debug=True)
