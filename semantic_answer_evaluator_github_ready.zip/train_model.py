"""
Model Training Script for Semantic Tree Logic Answer Evaluator.
Strictly calibrated for MONOTONIC SCORING:
- More missing keywords ALWAYS results in lower marks.
- 0% Keyword Match / Irrelevancy -> 0.0 Score
- 100% Keyword Match & Sound Logic -> 1.0 Score

Supports training on:
- Synthetic Multi-Subject Benchmark (--dataset default)
- Mohler Short Answer Grading Dataset (--dataset mohler)
- Kaggle ASAP-SAS Dataset (--dataset asap)
- Custom user CSV (--dataset custom --custom_path path/to/file.csv)

Usage:
    python train_model.py
    python train_model.py --dataset mohler
    python train_model.py --dataset asap
"""

import os
import sys
import argparse
import joblib
import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

from nlp_engine.evaluator import AnswerEvaluator

def generate_sample_dataset() -> pd.DataFrame:
    """Generates a rich multi-subject dataset enforcing strict monotonic keyword rules."""
    base_samples = [
        # --- Photosynthesis (7 required keywords) ---
        {
            "question": "What is photosynthesis and why is it important?",
            "reference_answer": "Photosynthesis is the process by which green plants use sunlight, carbon dioxide, and water to synthesize glucose and release oxygen into the atmosphere.",
            "keywords": "photosynthesis, sunlight, carbon dioxide, water, glucose, oxygen, plants",
            "student_answer": "Photosynthesis is the chemical process where plants use sunlight, carbon dioxide, and water to create glucose and oxygen.",
            "true_score": 1.0  # 7/7 keywords (100% match) -> 1.0 score
        },
        {
            "question": "What is photosynthesis and why is it important?",
            "reference_answer": "Photosynthesis is the process by which green plants use sunlight, carbon dioxide, and water to synthesize glucose and release oxygen into the atmosphere.",
            "keywords": "photosynthesis, sunlight, carbon dioxide, water, glucose, oxygen, plants",
            "student_answer": "Plants use photosynthesis with sunlight, carbon dioxide, and water to produce glucose.",
            "true_score": 0.75  # 5/7 keywords (71% match) -> 0.75 score
        },
        {
            "question": "What is photosynthesis and why is it important?",
            "reference_answer": "Photosynthesis is the process by which green plants use sunlight, carbon dioxide, and water to synthesize glucose and release oxygen into the atmosphere.",
            "keywords": "photosynthesis, sunlight, carbon dioxide, water, glucose, oxygen, plants",
            "student_answer": "Plants take in sunlight and water to produce oxygen.",
            "true_score": 0.45  # 3/7 keywords (43% match) -> 0.45 score
        },
        {
            "question": "What is photosynthesis and why is it important?",
            "reference_answer": "Photosynthesis is the process by which green plants use sunlight, carbon dioxide, and water to synthesize glucose and release oxygen into the atmosphere.",
            "keywords": "photosynthesis, sunlight, carbon dioxide, water, glucose, oxygen, plants",
            "student_answer": "Plants need sunlight.",
            "true_score": 0.20  # 1/7 keywords (14% match) -> 0.20 score
        },
        {
            "question": "What is photosynthesis and why is it important?",
            "reference_answer": "Photosynthesis is the process by which green plants use sunlight, carbon dioxide, and water to synthesize glucose and release oxygen into the atmosphere.",
            "keywords": "photosynthesis, sunlight, carbon dioxide, water, glucose, oxygen, plants",
            "student_answer": "The French Revolution began in 1789 due to social inequality in France.",
            "true_score": 0.0  # 0/7 keywords (0% match) -> 0.0 score (Irrelevant)
        },
        {
            "question": "What is photosynthesis and why is it important?",
            "reference_answer": "Photosynthesis is the process by which green plants use sunlight, carbon dioxide, and water to synthesize glucose and release oxygen into the atmosphere.",
            "keywords": "photosynthesis, sunlight, carbon dioxide, water, glucose, oxygen, plants",
            "student_answer": "Photosynthesis does not use sunlight or carbon dioxide and plants do not produce oxygen.",
            "true_score": 0.0  # Negation flip -> 0.0 score
        },

        # --- Newton's Second Law (6 required keywords) ---
        {
            "question": "State Newton's Second Law of Motion.",
            "reference_answer": "Newton's second law states that acceleration of an object is directly proportional to net force and inversely proportional to its mass, expressed as F = m * a.",
            "keywords": "acceleration, force, mass, proportional, inversely, formula",
            "student_answer": "Newton's second law of motion states force equals mass times acceleration, F = ma.",
            "true_score": 1.0  # 6/6 keywords -> 1.0 score
        },
        {
            "question": "State Newton's Second Law of Motion.",
            "reference_answer": "Newton's second law states that acceleration of an object is directly proportional to net force and inversely proportional to its mass, expressed as F = m * a.",
            "keywords": "acceleration, force, mass, proportional, inversely, formula",
            "student_answer": "Force depends on acceleration and mass.",
            "true_score": 0.50  # 3/6 keywords -> 0.50 score
        },
        {
            "question": "State Newton's Second Law of Motion.",
            "reference_answer": "Newton's second law states that acceleration of an object is directly proportional to net force and inversely proportional to its mass, expressed as F = m * a.",
            "keywords": "acceleration, force, mass, proportional, inversely, formula",
            "student_answer": "Database normalization reduces redundancy in SQL tables.",
            "true_score": 0.0  # 0/6 keywords -> 0.0 score
        }
    ]

    expanded = []
    np.random.seed(42)
    for sample in base_samples:
        expanded.append(sample)
        # Generate variations preserving strict ordering
        for _ in range(15):
            if sample["true_score"] == 0.0:
                noise_score = 0.0
            elif sample["true_score"] == 1.0:
                noise_score = 1.0
            else:
                noise_score = max(0.05, min(0.95, sample["true_score"] + np.random.normal(0, 0.02)))

            expanded.append({
                "question": sample["question"],
                "reference_answer": sample["reference_answer"],
                "keywords": sample["keywords"],
                "student_answer": sample["student_answer"],
                "true_score": round(noise_score, 4)
            })

    return pd.DataFrame(expanded)


def main():
    parser = argparse.ArgumentParser(description="Train Semantic Tree Logic short answer evaluator.")
    parser.add_argument("--dataset", type=str, default="default",
                        choices=["default", "mohler", "asap", "custom"],
                        help="Dataset to use for training (default, mohler, asap, custom)")
    parser.add_argument("--custom_path", type=str, default=None,
                        help="Path to custom CSV dataset if --dataset custom is chosen")
    args = parser.parse_args()

    print("=" * 65)
    print(f" 🚀 SEMANTIC TREE LOGIC MODEL TRAINING (DATASET: {args.dataset.upper()})")
    print("=" * 65)

    base_dir = os.path.dirname(os.path.abspath(__file__))
    models_dir = os.path.join(base_dir, "models")
    os.makedirs(models_dir, exist_ok=True)

    # 1. Load Dataset
    print(f"\n1. Loading Dataset [{args.dataset}]...")
    try:
        from data.dataset_loader import load_dataset
        df = load_dataset(dataset_type=args.dataset, custom_path=args.custom_path)
    except Exception as e:
        print(f"   [!] Note: dataset_loader could not be loaded ({e}). Falling back to synthetic generator.")
        df = generate_sample_dataset()

    csv_path = os.path.join(models_dir, "dataset.csv")
    df.to_csv(csv_path, index=False)
    print(f"   [+] Loaded and cached {len(df)} samples to {csv_path}")

    # 2. Extract Features
    print("\n2. Extracting Semantic Tree Features...")
    evaluator = AnswerEvaluator(model_dir=models_dir)

    feature_list = []
    y = []

    for idx, row in df.iterrows():
        kw_raw = str(row.get("keywords", ""))
        kw_list = [k.strip() for k in kw_raw.split(",") if k.strip()]
        feats = evaluator.extract_features(
            str(row["reference_answer"]),
            str(row["student_answer"]),
            key_concepts=kw_list
        )

        feature_list.append([
            feats["tree_edit_distance_score"],
            feats["subtree_overlap_score"],
            feats["spo_alignment_score"],
            feats["keyword_coverage_ratio"],
            feats["negation_penalty"],
            feats["length_ratio"]
        ])
        y.append(float(row["true_score"]))

    X = np.array(feature_list)
    y = np.array(y)

    print(f"   [+] Feature Matrix Shape: {X.shape}")

    # 3. Train Test Split
    test_size = 0.2 if len(X) >= 10 else 0.1
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)

    # 4. Feature Scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # 5. Model Training
    print("\n3. Training Gradient Boosting Regressor Model...")
    model = GradientBoostingRegressor(
        n_estimators=200,
        learning_rate=0.05,
        max_depth=4,
        random_state=42
    )
    model.fit(X_train_scaled, y_train)

    # 6. Evaluation
    y_pred = model.predict(X_test_scaled)

    # Enforce strict upper bound by keyword coverage ratio
    for i in range(len(X_test)):
        kw_cov = X_test[i][3] # keyword_coverage_ratio
        if kw_cov == 0.0:
            y_pred[i] = 0.0
        else:
            y_pred[i] = min(kw_cov, max(0.0, y_pred[i]))

    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)

    print("\n" + "=" * 45)
    print(" 📊 MODEL PERFORMANCE METRICS")
    print("=" * 45)
    print(f"   R² Score (Accuracy fit) : {r2 * 100:.2f}%")
    print(f"   Mean Absolute Error (MAE): {mae:.4f}")
    print(f"   Mean Squared Error (MSE) : {mse:.4f}")

    # Feature Importance
    feature_names = [
        "Tree Edit Distance",
        "Subtree Overlap",
        "SPO Alignment",
        "Keyword Coverage",
        "Negation Penalty",
        "Length Ratio"
    ]
    importances = model.feature_importances_

    print("\n 🌲 SEMANTIC TREE FEATURE IMPORTANCES:")
    for name, imp in zip(feature_names, importances):
        bar = "█" * int(imp * 30)
        print(f"   - {name:<20}: {imp:.4f} {bar}")

    # 7. Save Model Binaries
    model_save_path = os.path.join(models_dir, "semantic_tree_grader.joblib")
    scaler_save_path = os.path.join(models_dir, "feature_scaler.joblib")

    joblib.dump(model, model_save_path)
    joblib.dump(scaler, scaler_save_path)

    print("\n" + "=" * 65)
    print(f" ✅ Monotonic Model saved successfully to: {model_save_path}")
    print(f" ✅ Scaler saved successfully to: {scaler_save_path}")
    print("=" * 65)


if __name__ == "__main__":
    main()
